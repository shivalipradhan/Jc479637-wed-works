// JavaScript Document
var images = [ img1, img2, img3, img4]
var i=0;

function Slides() {
 document.getElementsById("mySlides").src = img[i];
  var dots = document.getElementsByClassName("dot");
 if	((i < slides.length - 1))
  i++;
  else i=0;
}
    
  
  setInterval(Slides, 2000); // Change image every 2 seconds
}